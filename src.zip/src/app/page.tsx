'use client';

import { useState, useMemo, useEffect } from 'react';
import ChapterSelectModal from '@/components/ChapterSelectModal';
import QuizView from '@/components/QuizView';
import ResultsView from '@/components/ResultsView';
import LearningStatusWidget from '@/components/LearningStatusWidget';
import ActionButtons from '@/components/ActionButtons';
import ReviewModeModal from '@/components/ReviewModeModal';
import LearningPlanSetup from '@/components/LearningPlanSetup';
import CurrentPlanWidget from '@/components/CurrentPlanWidget';
import SetupPromptWidget from '@/components/SetupPromptWidget';
import HomeSkeleton from '@/components/HomeSkeleton';
import RecentActivity from '@/components/RecentActivity';
import StreakWidget from '@/components/StreakWidget';
import AnalysisWidget from '@/components/AnalysisWidget';
import JoinAcademyWidget from '@/components/JoinAcademyWidget';
import JoinAcademyModal from '@/components/JoinAcademyModal';
import AcademyAssignmentWidget from '@/components/AcademyAssignmentWidget';
import { db, functions } from '@/firebase';
import { httpsCallable } from 'firebase/functions';
// ▼▼▼ 여기에 getDocs를 추가했습니다. ▼▼▼
import { collection, addDoc, serverTimestamp, doc, setDoc, getDoc, getDocs, updateDoc, query, where, orderBy, limit } from 'firebase/firestore';
import { useAuth } from '@/context/AuthContext';
import { useMyPageData } from '@/hooks/useMyPageData';
import toast from 'react-hot-toast';

type QuizMode = 'new' | 'mixed' | 'review_all' | 'review_incorrect';

export default function Home() {
  const { user } = useAuth();
  const { submissions, totalAnsweredCount, totalIncorrectCount, studyStreak, strongestChapter, weakestChapter, loading: dataLoading } = useMyPageData();
  
  const [studentData, setStudentData] = useState<any | null>(null);
  const [academyAssignment, setAcademyAssignment] = useState<any | null>(null);
  const [learningPlan, setLearningPlan] = useState<any | null>(null);
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [isSetupModalOpen, setIsSetupModalOpen] = useState(false);
  const [isJoinAcademyModalOpen, setIsJoinAcademyModalOpen] = useState(false);

  const [isChapterModalOpen, setIsChapterModalOpen] = useState(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [examQuestions, setExamQuestions] = useState<any[] | null>(null);
  const [quizResults, setQuizResults] = useState<{ questions: any[]; userAnswers: (number | null)[] } | null>(null);
  const [selectedQuizMode, setSelectedQuizMode] = useState<QuizMode | null>(null);

  useEffect(() => {
    if (!user) {
      setIsDataLoading(false);
      return;
    }
    const studentRef = doc(db, 'students', user.uid);
    const planRef = doc(db, 'learningPlans', user.uid);
    
    const fetchData = async () => {
      const [studentSnap, planSnap] = await Promise.all([getDoc(studentRef), getDoc(planRef)]);
      
      let currentStudentData = null;
      if (studentSnap.exists()) {
        currentStudentData = studentSnap.data();
        setStudentData(currentStudentData);
      }

      if (planSnap.exists()) setLearningPlan(planSnap.data());
      else setLearningPlan(null);

      // 학생이 학원에 소속되어 있다면, 과제를 가져옵니다.
      if (currentStudentData?.academyName && currentStudentData?.status === 'active') {
        const assignmentQuery = query(
          collection(db, 'academyAssignments'),
          where('academyName', '==', currentStudentData.academyName),
          orderBy('createdAt', 'desc'),
          limit(1)
        );
        const assignmentSnapshot = await getDocs(assignmentQuery);
        if (!assignmentSnapshot.empty) {
          setAcademyAssignment(assignmentSnapshot.docs[0].data());
        }
      }
      
      setIsDataLoading(false);
    };
    fetchData();
  }, [user]);

  const handleJoinAcademyRequest = async (academyName: string) => {
    if (!user) return;
    const studentRef = doc(db, 'students', user.uid);
    try {
      await updateDoc(studentRef, { academyName: academyName, status: 'pending' });
      setStudentData((prevData: any) => ({ ...prevData, academyName, status: 'pending' }));
      setIsJoinAcademyModalOpen(false);
      toast.success(`${academyName}에 가입 요청을 보냈습니다. 관리자 승인을 기다려주세요.`);
    } catch (error) {
      console.error("학원 가입 요청 실패:", error);
      toast.error("가입 요청에 실패했습니다.");
    }
  };

  const handleStartAssignment = () => {
    if (!academyAssignment) return;
    // 학원 과제는 항상 '신규+복습' 모드와 30문제로 시작합니다.
    handleSelectionComplete({
      unitIds: academyAssignment.assignedUnitIds,
      count: 30,
      mode: 'mixed'
    });
  };

  const recommendedMode = useMemo(() => {
    if (totalAnsweredCount >= 150) return 'mixed';
    return 'new';
  }, [totalAnsweredCount]);

  const startQuiz = (mode: QuizMode) => {
    setSelectedQuizMode(mode);
    setIsChapterModalOpen(true);
  };
  
  const handleStartReview = () => {
    setIsReviewModalOpen(true);
  };

  const handleReviewModeSelect = (mode: 'review_all' | 'review_incorrect') => {
    setIsReviewModalOpen(false);
    handleSelectionComplete({ unitIds: [], count: 30, mode });
  };

  const handleSelectionComplete = async (options: { unitIds: string[]; count: number; mode?: QuizMode }) => {
    setIsChapterModalOpen(false);
    setIsLoading(true);
    const modeToRequest = options.mode || selectedQuizMode;
    try {
      const generateExamFunction = httpsCallable(functions, 'generateExam');
      const result = await generateExamFunction({ unitIds: options.unitIds, questionCount: options.count, mode: modeToRequest });
      const questions = (result.data as { questions: any[] }).questions;
      setExamQuestions(questions);
      toast.success('시험지가 생성되었습니다!');
    } catch (error) {
      console.error("시험지 생성 중 오류:", error);
      toast.error("시험지를 생성하는 중 오류가 발생했습니다.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleQuizComplete = async (answers: (number | null)[]) => {
    if (!examQuestions || !user) return;
    let correctCount = 0;
    const incorrectQuestionIds: string[] = [];
    examQuestions.forEach((q, index) => {
      if (q.answerIndex === answers[index]) correctCount++;
      else incorrectQuestionIds.push(q.id);
    });
    const score = Math.round((correctCount / examQuestions.length) * 100);
    const submissionData = {
      userId: user.uid, createdAt: serverTimestamp(), score: score, answers: answers,
      questionIds: examQuestions.map(q => q.id), incorrectQuestionIds: incorrectQuestionIds,
      quizMode: selectedQuizMode, 
      mainChapter: examQuestions[0]?.mainChapter || '여러 단원',
      subChapter: examQuestions[0]?.subChapter || '혼합 학습',
      academyName: studentData?.academyName || null,
    };
    try {
      await addDoc(collection(db, "submissions"), submissionData);
      toast.success("답안이 저장되었습니다.");
    } catch (error) {
      console.error("Firestore 저장 오류:", error);
      toast.error("답안 저장에 실패했습니다.");
    }
    setQuizResults({ questions: examQuestions, userAnswers: answers });
    setExamQuestions(null);
  };
  
  const handleRestart = () => {
    setExamQuestions(null);
    setQuizResults(null);
  };
  
  const handleSavePlan = async (plan: any) => {
    if (!user) return;
    const planRef = doc(db, 'learningPlans', user.uid);
    const dataToSave = { ...plan, userId: user.uid, status: 'active', updatedAt: serverTimestamp() };
    if (!learningPlan) dataToSave.createdAt = serverTimestamp();
    await setDoc(planRef, dataToSave, { merge: true });
    setLearningPlan(dataToSave);
    setIsSetupModalOpen(false);
    toast.success("학습 계획이 저장되었습니다!");
  };

  if (quizResults) return <ResultsView questions={quizResults.questions} userAnswers={quizResults.userAnswers} onRestart={handleRestart} />;
  if (examQuestions) return <QuizView questions={examQuestions} onQuizComplete={handleQuizComplete} />;
  if (dataLoading || isDataLoading) {
    return (
      <main className="p-8 max-w-2xl mx-auto">
        <HomeSkeleton />
      </main>
    );
  }
  
  const isAcademyStudent = studentData?.academyName && studentData?.status === 'active';

  return (
    <main className="p-8 max-w-2xl mx-auto">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">안녕하세요, {user?.displayName || '학습자'}님!</h1>
          <p className="text-slate-500 mt-1">오늘도 목표를 향해 달려볼까요? 🔥</p>
        </div>
        <StreakWidget streakCount={studyStreak} />
      </div>

      {isAcademyStudent ? (
        <AcademyAssignmentWidget assignment={academyAssignment} onStart={handleStartAssignment} />
      ) : (
        <>
          {studentData && !studentData.academyName && (
            <JoinAcademyWidget onJoinClick={() => setIsJoinAcademyModalOpen(true)} />
          )}
          {studentData && studentData.status === 'pending' && (
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-r-lg mb-8">
                <p className="font-semibold text-blue-800">{studentData.academyName}의 승인을 기다리는 중입니다.</p>
            </div>
          )}
        </>
      )}
      
      {learningPlan ? (
        <CurrentPlanWidget plan={learningPlan} submissions={submissions} onEditClick={() => setIsSetupModalOpen(true)} onStartRecommended={() => startQuiz(recommendedMode)} />
      ) : (
        !isAcademyStudent && <SetupPromptWidget onSetupClick={() => setIsSetupModalOpen(true)} />
      )}
      
      <ActionButtons 
        recommendedMode={recommendedMode}
        onStartNewQuiz={() => startQuiz('new')}
        onStartRecommended={() => startQuiz(recommendedMode)}
        onStartReview={handleStartReview}
      />
      
      <AnalysisWidget strongestChapter={strongestChapter} weakestChapter={weakestChapter} />
      <RecentActivity submissions={submissions} />

      {isJoinAcademyModalOpen && <JoinAcademyModal onClose={() => setIsJoinAcademyModalOpen(false)} onConfirm={handleJoinAcademyRequest} />}
      {isChapterModalOpen && <ChapterSelectModal onClose={() => setIsChapterModalOpen(false)} onComplete={(opts) => handleSelectionComplete({ ...opts, mode: selectedQuizMode! })} />}
      {isReviewModalOpen && <ReviewModeModal onClose={() => setIsReviewModalOpen(false)} onSelectMode={handleReviewModeSelect} />}
      {isSetupModalOpen && <LearningPlanSetup onClose={() => setIsSetupModalOpen(false)} onSave={handleSavePlan} existingPlan={learningPlan} />}
    </main>
  );
}
