// src/context/AuthContext.tsx
'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { getAuth, onAuthStateChanged, User, signInWithCustomToken } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore'; // Firestore 도구 추가
import { db, functions } from '@/firebase'; // db 추가
import { httpsCallable } from 'firebase/functions';
import { useRouter, useSearchParams } from 'next/navigation';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  loginWithKakao: () => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const auth = getAuth();
  const router = useRouter();
  const searchParams = useSearchParams();

  // 사용자 정보가 변경될 때 Firestore의 students 문서와 동기화하는 함수
  const updateUserProfileInFirestore = async (firebaseUser: User) => {
    const studentRef = doc(db, 'students', firebaseUser.uid);
    const studentSnap = await getDoc(studentRef);

    if (!studentSnap.exists()) {
      // 새로운 사용자인 경우, students 컬렉션에 문서 생성
      await setDoc(studentRef, {
        studentName: firebaseUser.displayName,
        kakaoNickname: firebaseUser.displayName,
        email: firebaseUser.email,
        createdAt: serverTimestamp(),
        status: 'active', // 개인 사용자는 바로 활성 상태
        isDeleted: false,
        academyName: null, // 개인 사용자는 학원 없음
      });
      console.log(`New student document created for ${firebaseUser.uid}`);
    } else {
      // 기존 사용자인 경우, 정보 업데이트 (필요 시)
      // 예: await updateDoc(studentRef, { lastLogin: serverTimestamp() });
    }
  };

  useEffect(() => {
    const code = searchParams.get('code');
    if (code && !user) {
      setLoading(true);
      const kakaoLogin = httpsCallable(functions, 'kakaoLogin');
      kakaoLogin({ code: code })
        .then(result => {
          const token = (result.data as { firebase_token: string }).firebase_token;
          return signInWithCustomToken(auth, token);
        })
        .then((userCredential) => {
          // Firebase 로그인 성공 후 Firestore 프로필 동기화
          return updateUserProfileInFirestore(userCredential.user);
        })
        .then(() => {
          router.replace('/');
        })
        .catch(error => {
          console.error("Kakao login process failed:", error);
          alert("카카오 로그인에 실패했습니다. 다시 시도해주세요.");
          router.replace('/');
        });
    }
  }, [searchParams, auth, user, router]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
      if (currentUser) {
        // 페이지 새로고침 시에도 Firestore 프로필 동기화
        updateUserProfileInFirestore(currentUser);
      }
    });
    return () => unsubscribe();
  }, [auth]);
  
  const loginWithKakao = async () => {
    setLoading(true);
    try {
        const response = await fetch('https://asia-northeast3-rmcheck-4e79c.cloudfunctions.net/getKakaoLoginUrl');
        const data = await response.json();
        window.location.href = data.auth_url;
    } catch (error) {
        console.error("Failed to get Kakao login URL:", error);
        alert("로그인에 실패했습니다. 잠시 후 다시 시도해주세요.");
        setLoading(false);
    }
  };

  const logout = () => {
    auth.signOut();
  };

  const value = { user, loading, loginWithKakao, logout };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}