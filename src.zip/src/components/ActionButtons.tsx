'use client';

import { motion } from 'framer-motion';

type ActionButtonsProps = {
  recommendedMode: 'new' | 'mixed';
  onStartNewQuiz: () => void;
  onStartRecommended: () => void;
  onStartReview: () => void;
};

export default function ActionButtons({ recommendedMode, onStartNewQuiz, onStartRecommended, onStartReview }: ActionButtonsProps) {
  return (
    <section>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 오늘의 추천 학습 (핵심 기능) */}
        <motion.button
          whileHover={{ scale: 1.03, y: -2, transition: { type: 'spring', stiffness: 300 } }}
          whileTap={{ scale: 0.98, transition: { type: 'spring', stiffness: 400, damping: 15 } }}
          onClick={onStartRecommended}
          className="md:col-span-2 text-center p-6 bg-primary text-white rounded-lg shadow-lg flex flex-col items-center justify-center"
        >
          <div className="mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z" /></svg>
          </div>
          {recommendedMode === 'new' ? (
            <>
              <h3 className="text-xl font-bold">오늘의 추천 학습 (신규)</h3>
              <p className="mt-1 text-sm opacity-90">새로운 문제 풀이로 학습을 시작해보세요!</p>
            </>
          ) : (
            <>
              <h3 className="text-xl font-bold">오늘의 추천 학습 (신규+복습)</h3>
              <p className="mt-1 text-sm opacity-90">새로운 문제와 복습 문제를 조합하여 학습합니다.</p>
            </>
          )}
        </motion.button>
        
        {/* 새로운 문제만 풀기 */}
        <motion.button
          whileHover={{ scale: 1.03, y: -2, transition: { type: 'spring', stiffness: 300 } }}
          whileTap={{ scale: 0.98, transition: { type: 'spring', stiffness: 400, damping: 15 } }}
          onClick={onStartNewQuiz}
          className="text-center p-6 bg-white text-slate-800 rounded-lg shadow-md border hover:bg-slate-50 flex flex-col items-center justify-center"
        >
          <div className="mb-2 text-primary">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.311a7.5 7.5 0 0 1-7.5 0c-1.421-.492-2.682-.998-3.624-1.513a1.125 1.125 0 0 1-1.472-1.26c.27-1.202.648-2.35 1.074-3.464.426-1.114 1.027-2.138 1.746-3.07C7.556 7.607 8.68 6.73 9.929 6.035c1.25-.694 2.557-1.215 3.929-1.549a1.125 1.125 0 0 1 1.348 1.125 11.953 11.953 0 0 1-1.015 5.223m-2.25-1.332a12.022 12.022 0 0 1-3.75 0" /></svg>
          </div>
          <h3 className="text-lg font-bold">새로운 문제만 풀기</h3>
        </motion.button>

        {/* 자유 복습 */}
        <motion.button
          whileHover={{ scale: 1.03, y: -2, transition: { type: 'spring', stiffness: 300 } }}
          whileTap={{ scale: 0.98, transition: { type: 'spring', stiffness: 400, damping: 15 } }}
          onClick={onStartReview}
          className="text-center p-6 bg-white text-slate-800 rounded-lg shadow-md border hover:bg-slate-50 flex flex-col items-center justify-center"
        >
          <div className="mb-2 text-primary">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 11.667 0l3.181-3.183m-4.991-2.691v4.992h-4.992m0 0-3.181-3.183a8.25 8.25 0 0 1 11.667 0l3.181 3.183" /></svg>
          </div>
          <h3 className="text-lg font-bold">자유 복습</h3>
        </motion.button>
      </div>
    </section>
  );
}
