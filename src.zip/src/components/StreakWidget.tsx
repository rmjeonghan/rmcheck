'use client';

import { motion } from 'framer-motion';

export default function StreakWidget({ streakCount }: { streakCount: number }) {
  if (streakCount === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center space-x-2 bg-orange-100 text-orange-600 font-bold px-3 py-1.5 rounded-full text-sm"
    >
      <span>🔥</span>
      <span>{streakCount}일 연속 학습 중!</span>
    </motion.div>
  );
}
