'use client';

import { motion } from 'framer-motion';
import { format } from 'date-fns';

type AcademyAssignmentWidgetProps = {
  assignment: any;
  onStart: () => void;
};

export default function AcademyAssignmentWidget({ assignment, onStart }: AcademyAssignmentWidgetProps) {
  if (!assignment) return null;

  const dueDate = assignment.dueDate ? new Date(assignment.dueDate) : null;

  return (
    <motion.section 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border-2 border-primary p-6 rounded-lg shadow-lg mb-8"
    >
      <div className="flex justify-between items-start">
        <div>
          <span className="text-xs font-semibold bg-primary/10 text-primary px-2 py-1 rounded-full">
            학원 과제
          </span>
          <h2 className="text-2xl font-bold text-slate-800 mt-2">{assignment.assignmentName}</h2>
          {dueDate && (
            <p className="text-sm text-gray-500 mt-1">
              마감일: {format(dueDate, 'yyyy년 MM월 dd일')}
            </p>
          )}
        </div>
        <button
          onClick={onStart}
          className="px-6 py-3 bg-primary text-white font-bold rounded-lg hover:bg-primary-hover transition-colors whitespace-nowrap"
        >
          과제 시작하기
        </button>
      </div>
    </motion.section>
  );
}
