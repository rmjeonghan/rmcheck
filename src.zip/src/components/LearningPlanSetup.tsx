// src/components/LearningPlanSetup.tsx
'use client';

import { useState, useMemo } from 'react';
import { add, format } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion'; // motion과 AnimatePresence를 가져옵니다.

type LearningPlanSetupProps = {
  onClose: () => void;
  onSave: (plan: any) => void;
  existingPlan?: any;
};

const WEEKDAYS = ['일', '월', '화', '수', '목', '금', '토'];
const DEFAULT_DAYS_BY_FREQ: { [key: number]: number[] } = {
  1: [1], 2: [1, 3], 3: [1, 3, 5], 4: [1, 3, 5, 0],
  5: [1, 2, 3, 4, 5], 6: [1, 2, 3, 4, 5, 6], 7: [0, 1, 2, 3, 4, 5, 6],
};

export default function LearningPlanSetup({ onClose, onSave, existingPlan }: LearningPlanSetupProps) {
  const [durationWeeks, setDurationWeeks] = useState(existingPlan?.durationWeeks || 3);
  const [startDate, setStartDate] = useState(existingPlan?.startDate?.toDate() || new Date());
  const [frequency, setFrequency] = useState(existingPlan?.studyDays?.length || 5);
  const [studyDays, setStudyDays] = useState<number[]>(existingPlan?.studyDays || DEFAULT_DAYS_BY_FREQ[5]);

  const endDate = useMemo(() => add(startDate, { weeks: durationWeeks, days: -1 }), [startDate, durationWeeks]);

  const handleFrequencyChange = (newFrequency: number) => {
    setFrequency(newFrequency);
    if (!existingPlan) {
      setStudyDays(DEFAULT_DAYS_BY_FREQ[newFrequency]);
    }
  };

  const handleDayToggle = (dayIndex: number) => {
    setStudyDays(prevDays => {
      const newDays = prevDays.includes(dayIndex)
        ? prevDays.filter(d => d !== dayIndex)
        : [...prevDays, dayIndex].sort(); // 요일을 순서대로 정렬
      setFrequency(newDays.length);
      return newDays;
    });
  };
  
  const handleSave = () => {
    const plan = { startDate, endDate, studyDays };
    console.log("저장될 학습 계획:", plan);
    onSave(plan);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center p-4 z-50">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-lg shadow-xl w-full max-w-lg flex flex-col"
      >
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-xl font-bold">{existingPlan ? '학습 계획 수정' : '학습 계획 설정'}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
          <div>
            <h3 className="text-lg font-semibold mb-2">1. 학습 기간 선택</h3>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4].map(week => (
                <motion.button key={week} onClick={() => setDurationWeeks(week)} className={`p-3 rounded-md font-semibold transition-colors ${durationWeeks === week ? 'bg-primary text-white' : 'bg-gray-200 hover:bg-gray-300'}`} whileTap={{ scale: 0.95 }}>
                  {week}주
                </motion.button>
              ))}
            </div>
          </div>

          <div className="p-4 bg-gray-50 rounded-md text-center">
            <p className="text-sm text-gray-600">학습 기간</p>
            <p className="font-bold text-lg">
              {format(startDate, 'yyyy.MM.dd')} ~ {format(endDate, 'yyyy.MM.dd')}
            </p>
          </div>

          <div>
            <label htmlFor="frequencyRange" className="block text-lg font-semibold mb-2">
              2. 주당 학습 횟수: 
              <AnimatePresence mode="wait">
                <motion.span
                  key={frequency} // key가 바뀌면 애니메이션이 다시 실행됩니다.
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="inline-block text-primary font-bold ml-2"
                >
                  주 {frequency}회
                </motion.span>
              </AnimatePresence>
            </label>
            <input id="frequencyRange" type="range" min="1" max="7" step="1" value={frequency} onChange={(e) => handleFrequencyChange(parseInt(e.target.value, 10))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"/>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-2">3. 학습 요일 선택</h3>
            <div className="grid grid-cols-7 gap-2">
              {WEEKDAYS.map((day, index) => (
                <motion.button key={day} onClick={() => handleDayToggle(index)} className={`p-3 rounded-md font-semibold transition-colors text-center ${studyDays.includes(index) ? 'bg-primary text-white' : 'bg-gray-200 hover:bg-gray-300'}`} whileTap={{ scale: 0.95 }}>
                  {day}
                </motion.button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-4 bg-gray-50 border-t text-right">
          <motion.button onClick={handleSave} className="px-8 py-3 bg-primary text-white font-bold rounded-lg hover:bg-primary-hover" whileTap={{ scale: 0.98 }}>
            계획 저장하기
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
