// src/components/CurrentPlanWidget.tsx
'use client';

import { useMemo } from 'react';
import { format, differenceInWeeks, differenceInDays, isSameDay, getDay } from 'date-fns';

type CurrentPlanWidgetProps = {
  plan: any;
  submissions: any[];
  onEditClick: () => void;
  onStartRecommended: () => void;
};

const WEEKDAYS = ['일', '월', '화', '수', '목', '금', '토'];

export default function CurrentPlanWidget({ plan, submissions, onEditClick, onStartRecommended }: CurrentPlanWidgetProps) {
  const { startDate, endDate, studyDays } = useMemo(() => {
    return {
      startDate: plan.startDate?.toDate(),
      endDate: plan.endDate?.toDate(),
      studyDays: plan.studyDays || [],
    };
  }, [plan]);

  const { currentWeek, weekProgress, isStudyDay, nextActionText } = useMemo(() => {
    if (!startDate || !endDate) return { currentWeek: 0, weekProgress: 0, isStudyDay: false, nextActionText: "학습 계획을 시작하세요!" };

    const today = new Date();
    const currentWeek = differenceInWeeks(today, startDate) + 1;
    
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - getDay(today)); // 이번 주 일요일
    
    const completedThisWeek = submissions.filter(s => {
      const submissionDate = s.createdAt.toDate();
      return submissionDate >= startOfWeek && submissionDate <= today;
    }).length;

    const weekProgress = studyDays.length > 0 ? (completedThisWeek / studyDays.length) * 100 : 0;
    const isStudyDay = studyDays.includes(getDay(today));
    
    let nextActionText = "오늘의 추천 학습 시작하기";
    if (!isStudyDay) nextActionText = "오늘은 쉬는 날입니다! 🧘";
    if (isSameDay(today, startDate)) nextActionText = "새로운 학습 계획을 시작하세요! 🎉";

    return { currentWeek, weekProgress, isStudyDay, nextActionText };
  }, [startDate, endDate, studyDays, submissions]);

  if (!startDate) return null;

  return (
    <section className="bg-gray-50 p-6 rounded-lg shadow mb-8">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">나의 학습 계획</h2>
          <p className="text-sm text-gray-600 mt-1">
            {format(startDate, 'yyyy.MM.dd')} ~ {format(endDate, 'yyyy.MM.dd')}
          </p>
        </div>
        <button onClick={onEditClick} className="px-5 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors text-sm whitespace-nowrap">
          계획 수정
        </button>
      </div>

      <div>
        <div className="flex justify-between text-sm font-semibold mb-1">
          <span>이번 주 진행도 ({currentWeek}주차)</span>
          <span>{Math.round(weekProgress)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-primary h-2.5 rounded-full" style={{ width: `${weekProgress}%` }}></div>
        </div>
      </div>

      <button
        onClick={onStartRecommended}
        disabled={!isStudyDay}
        className="w-full mt-4 py-3 bg-primary text-white font-bold rounded-lg hover:bg-primary-hover disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
      >
        {nextActionText}
      </button>
    </section>
  );
}
