'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/firebase';
import { collection, query, where, getDocs, documentId, orderBy } from 'firebase/firestore';
import { differenceInCalendarDays, parseISO, format } from 'date-fns';

export interface Submission {
  id: string;
  score: number;
  createdAt: { toDate: () => Date };
  questionIds: string[];
  incorrectQuestionIds: string[];
  mainChapter: string;
}

export interface MyPageData {
  submissions: Submission[];
  incorrectQuestions: any[];
  totalAnsweredCount: number;
  totalIncorrectCount: number;
  studyStreak: number;
  strongestChapter: string | null;
  weakestChapter: string | null;
  loading: boolean;
}

export function useMyPageData(): MyPageData {
  const { user } = useAuth();
  const [data, setData] = useState<Omit<MyPageData, 'loading'>>({
    submissions: [],
    incorrectQuestions: [],
    totalAnsweredCount: 0,
    totalIncorrectCount: 0,
    studyStreak: 0,
    strongestChapter: null,
    weakestChapter: null,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      setLoading(true);
      try {
        const submissionsQuery = query(collection(db, 'submissions'), where('userId', '==', user.uid), orderBy('createdAt', 'desc'));
        const submissionsSnapshot = await getDocs(submissionsQuery);
        const userSubmissions = submissionsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Submission));

        const allIncorrectIds = [...new Set(userSubmissions.flatMap(s => s.incorrectQuestionIds || []))];
        const allAnsweredIds = [...new Set(userSubmissions.flatMap(s => s.questionIds || []))];

        let allAnsweredQuestions: any[] = [];
        if (allAnsweredIds.length > 0) {
            const promises = [];
            for (let i = 0; i < allAnsweredIds.length; i += 30) {
                const chunk = allAnsweredIds.slice(i, i + 30);
                const q = query(collection(db, 'questionBank'), where(documentId(), 'in', chunk));
                promises.push(getDocs(q));
            }
            const questionSnapshots = await Promise.all(promises);
            allAnsweredQuestions = questionSnapshots.flatMap(snap => snap.docs.map(d => ({ id: d.id, ...d.data() })));
        }
        
        const incorrectQuestionsData = allAnsweredQuestions.filter(q => allIncorrectIds.includes(q.id));

        const submissionDates = [...new Set(userSubmissions.map(s => format(s.createdAt.toDate(), 'yyyy-MM-dd')))].sort().reverse();
        let streak = 0;
        if (submissionDates.length > 0) {
            const today = new Date();
            const lastDate = parseISO(submissionDates[0]);
            if (differenceInCalendarDays(today, lastDate) <= 1) {
                streak = 1;
                for (let i = 0; i < submissionDates.length - 1; i++) {
                    const current = parseISO(submissionDates[i]);
                    const previous = parseISO(submissionDates[i + 1]);
                    if (differenceInCalendarDays(current, previous) === 1) streak++;
                    else break;
                }
            }
        }
        
        // ▼▼▼ '중단원' 단위로 분석 로직을 변경합니다. ▼▼▼
        const subChapterStats: { [key: string]: { correct: number, total: number } } = {};
        
        allAnsweredQuestions.forEach(question => {
            const subChapter = question.subChapter; // 대단원 대신 중단원을 기준으로 삼습니다.
            if (!subChapter) return;

            if (!subChapterStats[subChapter]) {
                subChapterStats[subChapter] = { correct: 0, total: 0 };
            }
            
            subChapterStats[subChapter].total++;
            if (!allIncorrectIds.includes(question.id)) {
                subChapterStats[subChapter].correct++;
            }
        });

        const analyzableChapters = Object.entries(subChapterStats)
            .filter(([_, stats]) => stats.total >= 5) // 최소 5문제 이상 푼 '중단원'만 분석
            .map(([chapter, stats]) => ({
                name: chapter,
                rate: (stats.correct / stats.total) * 100,
            }));

        let strongest: string | null = null;
        let weakest: string | null = null;

        if (analyzableChapters.length >= 2) {
            analyzableChapters.sort((a, b) => a.rate - b.rate);
            weakest = analyzableChapters[0].name;
            strongest = analyzableChapters[analyzableChapters.length - 1].name;
        } else if (analyzableChapters.length === 1) {
            if (analyzableChapters[0].rate >= 80) {
                strongest = analyzableChapters[0].name;
            } else if (analyzableChapters[0].rate <= 60) {
                weakest = analyzableChapters[0].name;
            }
        }
        // ▲▲▲ 여기까지 수정 ▲▲▲

        setData({
          submissions: userSubmissions,
          incorrectQuestions: incorrectQuestionsData,
          totalAnsweredCount: allAnsweredIds.length,
          totalIncorrectCount: allIncorrectIds.length,
          studyStreak: streak,
          strongestChapter: strongest,
          weakestChapter: weakest,
        });

      } catch (error) {
        console.error("마이페이지 데이터 로딩 실패:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  return { ...data, loading };
}
